import Habit from './Habit';

const HabitList = () => {
  return (
    <section>
      <h2>My Habits</h2>
      <Habit />
      <Habit />
      <Habit />
    </section>
  );
};

export default HabitList;
