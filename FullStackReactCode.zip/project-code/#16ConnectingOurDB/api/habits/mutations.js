export const habitsMutations = {
  Mutation: {
    async addHabit(_, { habit }) {
      console.log('add habit');
    }
  }
};
