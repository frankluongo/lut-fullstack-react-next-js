import Layout from '../../components/Layout';

const Event = () => {
  return (
    <Layout>
      <h1>Event</h1>
    </Layout>
  );
};

export default Event;
